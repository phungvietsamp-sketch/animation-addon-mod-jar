/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.event.interaction;

import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.impl.networking.UntrackedNetworkHandler;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_7648;

public final class FakePlayerNetworkHandler extends class_3244 implements UntrackedNetworkHandler {
	private static final class_2535 FAKE_CONNECTION = new class_2535(class_2598.field_11942);

	public FakePlayerNetworkHandler(class_3222 player) {
		super(player.method_5682(), FAKE_CONNECTION, player);
	}

	@Override
	public void method_14369(class_2596<?> packet, @Nullable class_7648 callbacks) { }
}
