/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.conditions;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.fabricmc.fabric.impl.resource.conditions.ResourceConditionsImpl;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_5455;
import net.minecraft.class_60;
import net.minecraft.class_8490;

/**
 * Starting with 1.20, LootManager directly implements ResourceReloader.
 */
@Mixin(class_60.class)
public class LootManagerMixin {
	// Keep track of the DynamicRegistryManager instance by assgining it to the map that is passed to the async runnable.
	@Unique
	private static final Map<Object, class_5455.class_6890> dynamicRegistryManagerMap = Collections.synchronizedMap(new IdentityHashMap<>());

	@Inject(method = "load", at = @At(value = "INVOKE", target = "Ljava/util/concurrent/CompletableFuture;runAsync(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)Ljava/util/concurrent/CompletableFuture;"), locals = LocalCapture.CAPTURE_FAILHARD)
	private static void load(class_8490 type, class_3300 resourceManager, Executor executor, Map<class_8490<?>, Map<class_2960, ?>> results, CallbackInfoReturnable<CompletableFuture<?>> cir, Map map) {
		dynamicRegistryManagerMap.put(map, ResourceConditionsImpl.CURRENT_REGISTRIES.get());
	}

	// runAsync Runnable in load method
	@Inject(method = "method_51189", at = @At("HEAD"))
	private static void runAsync(class_3300 resourceManager, class_8490 lootDataType, Map map, CallbackInfo ci) {
		assert ResourceConditionsImpl.CURRENT_REGISTRIES.get() == null;
		ResourceConditionsImpl.CURRENT_REGISTRIES.set(Objects.requireNonNull(dynamicRegistryManagerMap.remove(map)));
	}

	// forEach in load method
	@Inject(method = "method_51195", at = @At("HEAD"), cancellable = true)
	private static void applyResourceConditions(class_8490 lootDataType, Map map, class_2960 id, JsonElement json, CallbackInfo ci) {
		if (json.isJsonObject()) {
			JsonObject obj = json.getAsJsonObject();

			if (obj.has(ResourceConditions.CONDITIONS_KEY)) {
				boolean matched = ResourceConditions.objectMatchesConditions(obj);

				if (!matched) {
					ci.cancel();
				}

				if (ResourceConditionsImpl.LOGGER.isDebugEnabled()) {
					String verdict = matched ? "Allowed" : "Rejected";
					ResourceConditionsImpl.LOGGER.debug("{} resource of type {} with id {}", verdict, lootDataType.method_51214(), id);
				}
			}
		}
	}

	// runAsync Runnable in load method
	@Inject(method = "method_51189", at = @At("RETURN"))
	private static void runAsyncEnd(class_3300 resourceManager, class_8490 lootDataType, Map map, CallbackInfo ci) {
		ResourceConditionsImpl.CURRENT_REGISTRIES.remove();
	}
}
