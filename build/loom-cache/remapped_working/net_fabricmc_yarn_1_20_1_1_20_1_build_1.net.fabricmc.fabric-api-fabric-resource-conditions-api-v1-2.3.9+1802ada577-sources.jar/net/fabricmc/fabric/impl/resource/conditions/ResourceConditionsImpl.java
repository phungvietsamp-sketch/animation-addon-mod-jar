/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.conditions;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import com.google.common.base.Preconditions;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3505;
import net.minecraft.class_3518;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7696;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7924;

public final class ResourceConditionsImpl {
	public static final Logger LOGGER = LoggerFactory.getLogger("Fabric Resource Conditions");

	// Providers

	public static ConditionJsonProvider array(class_2960 id, ConditionJsonProvider... values) {
		Preconditions.checkArgument(values.length > 0, "Must register at least one value.");

		return new ConditionJsonProvider() {
			@Override
			public class_2960 getConditionId() {
				return id;
			}

			@Override
			public void writeParameters(JsonObject object) {
				JsonArray array = new JsonArray();

				for (ConditionJsonProvider provider : values) {
					array.add(provider.toJson());
				}

				object.add("values", array);
			}
		};
	}

	public static ConditionJsonProvider mods(class_2960 id, String... modIds) {
		Preconditions.checkArgument(modIds.length > 0, "Must register at least one mod id.");

		return new ConditionJsonProvider() {
			@Override
			public class_2960 getConditionId() {
				return id;
			}

			@Override
			public void writeParameters(JsonObject object) {
				JsonArray array = new JsonArray();

				for (String modId : modIds) {
					array.add(modId);
				}

				object.add("values", array);
			}
		};
	}

	@SafeVarargs
	public static <T> ConditionJsonProvider tagsPopulated(class_2960 id, boolean includeRegistry, class_6862<T>... tags) {
		Preconditions.checkArgument(tags.length > 0, "Must register at least one tag.");
		final class_5321<? extends class_2378<?>> registryRef = tags[0].comp_326();

		return new ConditionJsonProvider() {
			@Override
			public class_2960 getConditionId() {
				return id;
			}

			@Override
			public void writeParameters(JsonObject object) {
				JsonArray array = new JsonArray();

				for (class_6862<T> tag : tags) {
					array.add(tag.comp_327().toString());
				}

				object.add("values", array);

				if (includeRegistry && registryRef != class_7924.field_41197) {
					// tags[0] is guaranteed to exist.
					// Skip if this is the default (minecraft:item)
					object.addProperty("registry", registryRef.method_29177().toString());
				}
			}
		};
	}

	public static ConditionJsonProvider featuresEnabled(class_2960 id, final class_7696... features) {
		final Set<class_2960> ids = new TreeSet<>(class_7701.field_40180.method_45392(class_7701.field_40180.method_45390(features)));

		return new ConditionJsonProvider() {
			@Override
			public class_2960 getConditionId() {
				return id;
			}

			@Override
			public void writeParameters(JsonObject object) {
				JsonArray array = new JsonArray();

				for (class_2960 id : ids) {
					array.add(id.toString());
				}

				object.add("features", array);
			}
		};
	}

	public static ConditionJsonProvider registryContains(class_2960 id, class_2960 registry, class_2960... entries) {
		Preconditions.checkArgument(entries.length > 0, "Must register at least one entry.");

		return new ConditionJsonProvider() {
			@Override
			public class_2960 getConditionId() {
				return id;
			}

			@Override
			public void writeParameters(JsonObject object) {
				JsonArray array = new JsonArray();

				for (class_2960 entry : entries) {
					array.add(entry.toString());
				}

				object.add("values", array);

				if (!class_7924.field_41197.method_29177().equals(registry)) {
					// Skip if this is the default (minecraft:item)
					object.addProperty("registry", registry.toString());
				}
			}
		};
	}

	// Condition implementations

	public static boolean modsLoadedMatch(JsonObject object, boolean and) {
		JsonArray array = class_3518.method_15261(object, "values");

		for (JsonElement element : array) {
			if (element.isJsonPrimitive()) {
				if (FabricLoader.getInstance().isModLoaded(element.getAsString()) != and) {
					return !and;
				}
			} else {
				throw new JsonParseException("Invalid mod id entry: " + element);
			}
		}

		return and;
	}

	/**
	 * Stores the tags deserialized by {@link class_3505} before they are bound, to use them in the tags_populated conditions.
	 * The tags are set at the end of the "apply" phase in {@link class_3505}, and cleared in {@link net.minecraft.class_5350#method_40421}.
	 * If the resource reload fails, the thread local is not cleared and:
	 * - the map will remain in memory until the next reload;
	 * - any call to {@link #tagsPopulatedMatch} will check the tags from the failed reload instead of failing directly.
	 * This is probably acceptable.
	 */
	public static final ThreadLocal<Map<class_5321<?>, Map<class_2960, Collection<class_6880<?>>>>> LOADED_TAGS = new ThreadLocal<>();

	@SuppressWarnings({"unchecked", "rawtypes"})
	public static void setTags(List<class_3505.class_6863<?>> tags) {
		Map<class_5321<?>, Map<class_2960, Collection<class_6880<?>>>> tagMap = new HashMap<>();

		for (class_3505.class_6863<?> registryTags : tags) {
			tagMap.put(registryTags.comp_328(), (Map) registryTags.comp_329());
		}

		LOADED_TAGS.set(tagMap);
	}

	public static boolean tagsPopulatedMatch(JsonObject object) {
		String key = class_3518.method_15253(object, "registry", "minecraft:item");
		class_5321<? extends class_2378<?>> registryRef = class_5321.method_29180(new class_2960(key));
		return tagsPopulatedMatch(object, registryRef);
	}

	public static boolean tagsPopulatedMatch(JsonObject object, class_5321<? extends class_2378<?>> registryKey) {
		JsonArray array = class_3518.method_15261(object, "values");
		@Nullable
		Map<class_5321<?>, Map<class_2960, Collection<class_6880<?>>>> allTags = LOADED_TAGS.get();

		if (allTags == null) {
			LOGGER.warn("Can't retrieve deserialized tags. Failing tags_populated resource condition check.");
			return false;
		}

		Map<class_2960, Collection<class_6880<?>>> registryTags = allTags.get(registryKey);

		if (registryTags == null) {
			// No tag for this registry
			return array.isEmpty();
		}

		for (JsonElement element : array) {
			if (element.isJsonPrimitive()) {
				class_2960 id = new class_2960(element.getAsString());
				Collection<class_6880<?>> tags = registryTags.get(id);

				if (tags == null || tags.isEmpty()) {
					return false;
				}
			} else {
				throw new JsonParseException("Invalid tag id entry: " + element);
			}
		}

		return true;
	}

	public static final ThreadLocal<class_7699> CURRENT_FEATURES = ThreadLocal.withInitial(() -> class_7701.field_40183);

	public static boolean featuresEnabledMatch(JsonObject object) {
		List<class_2960> featureIds = class_3518.method_15261(object, "features").asList().stream().map((element) -> new class_2960(element.getAsString())).toList();
		class_7699 set = class_7701.field_40180.method_45388(featureIds, (id) -> {
			throw new JsonParseException("Unknown feature flag: " + id);
		});

		return set.method_45400(CURRENT_FEATURES.get());
	}

	public static final ThreadLocal<class_5455.class_6890> CURRENT_REGISTRIES = new ThreadLocal<>();

	public static boolean registryContainsMatch(JsonObject object) {
		String key = class_3518.method_15253(object, "registry", "minecraft:item");
		class_5321<? extends class_2378<?>> registryRef = class_5321.method_29180(new class_2960(key));
		return registryContainsMatch(object, registryRef);
	}

	private static <E> boolean registryContainsMatch(JsonObject object, class_5321<? extends class_2378<? extends E>> registryRef) {
		JsonArray array = class_3518.method_15261(object, "values");
		class_5455.class_6890 registries = CURRENT_REGISTRIES.get();

		if (registries == null) {
			LOGGER.warn("Can't retrieve current registries. Failing registry_contains resource condition check.");
			return false;
		}

		Optional<class_2378<E>> registry = registries.method_33310(registryRef);

		if (registry.isEmpty()) {
			// No such registry
			return array.isEmpty();
		}

		for (JsonElement element : array) {
			if (element.isJsonPrimitive()) {
				class_2960 id = new class_2960(element.getAsString());

				if (!registry.get().method_10250(id)) {
					return false;
				}
			} else {
				throw new JsonParseException("Invalid registry entry id: " + element);
			}
		}

		return true;
	}
}
