/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.networking.v0;

import java.util.Objects;
import PlayerEntity;
import ThreadExecutor;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.network.ClientSidePacketRegistry;
import net.fabricmc.fabric.api.network.PacketConsumer;
import net.fabricmc.fabric.api.network.PacketContext;
import net.fabricmc.fabric.api.network.PacketRegistry;
import net.fabricmc.fabric.impl.networking.GenericFutureListenerHolder;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class ClientSidePacketRegistryImpl implements ClientSidePacketRegistry, PacketRegistry {
	@Override
	public boolean canServerReceive(class_2960 id) {
		return ClientPlayNetworking.getSendable().contains(id);
	}

	@Override
	public void sendToServer(class_2596<?> packet, GenericFutureListener<? extends Future<? super Void>> completionListener) {
		if (class_310.method_1551().method_1562() != null) {
			class_310.method_1551().method_1562().method_48296().method_10752(packet, GenericFutureListenerHolder.create(completionListener));
			return;
		}

		throw new IllegalStateException("Cannot send packet to server while not in game!"); // TODO: Error message
	}

	@Override
	public class_2596<?> toPacket(class_2960 id, class_2540 buf) {
		return ClientPlayNetworking.createC2SPacket(id, buf);
	}

	@Override
	public void register(class_2960 id, PacketConsumer consumer) {
		// id is checked in client networking
		Objects.requireNonNull(consumer, "PacketConsumer cannot be null");

		ClientPlayNetworking.registerGlobalReceiver(id, (client, handler, buf, sender) -> {
			consumer.accept(new PacketContext() {
				@Override
				public EnvType getPacketEnvironment() {
					return EnvType.CLIENT;
				}

				@Override
				public PlayerEntity getPlayer() {
					return client.player;
				}

				@Override
				public ThreadExecutor<?> getTaskQueue() {
					return client;
				}
			}, buf);
		});
	}

	@Override
	public void unregister(class_2960 id) {
		ClientPlayNetworking.unregisterGlobalReceiver(id);
	}
}
