/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.loader;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3294;
import net.minecraft.class_3298;
import net.minecraft.class_7367;
import net.minecraft.class_7368;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;

/**
 * Represents a group resource pack, holds multiple resource packs as one.
 */
public abstract class GroupResourcePack implements class_3262 {
	protected final class_3264 type;
	protected final List<? extends class_3262> packs;
	protected final Map<String, List<class_3262>> namespacedPacks = new Object2ObjectOpenHashMap<>();

	public GroupResourcePack(class_3264 type, List<? extends class_3262> packs) {
		this.type = type;
		this.packs = packs;
		this.packs.forEach(pack -> pack.method_14406(this.type)
				.forEach(namespace -> this.namespacedPacks.computeIfAbsent(namespace, value -> new ArrayList<>())
						.add(pack)));
	}

	@Override
	public class_7367<InputStream> method_14405(class_3264 type, class_2960 id) {
		List<? extends class_3262> packs = this.namespacedPacks.get(id.method_12836());

		if (packs != null) {
			// Last to first, since higher priority packs are at the end
			for (int i = packs.size() - 1; i >= 0; i--) {
				class_3262 pack = packs.get(i);
				class_7367<InputStream> supplier = pack.method_14405(type, id);

				if (supplier != null) {
					return supplier;
				}
			}
		}

		return null;
	}

	@Override
	public void method_14408(class_3264 type, String namespace, String prefix, class_7664 consumer) {
		List<? extends class_3262> packs = this.namespacedPacks.get(namespace);

		if (packs == null) {
			return;
		}

		// First to last, since later calls override previously returned data
		for (class_3262 pack : packs) {
			pack.method_14408(type, namespace, prefix, consumer);
		}
	}

	@Override
	public Set<String> method_14406(class_3264 type) {
		return this.namespacedPacks.keySet();
	}

	public void appendResources(class_3264 type, class_2960 id, List<class_3298> resources) {
		List<? extends class_3262> packs = this.namespacedPacks.get(id.method_12836());

		if (packs == null) {
			return;
		}

		class_2960 metadataId = class_3294.method_14473(id);

		// Last to first, since higher priority packs are at the end
		for (int i = packs.size() - 1; i >= 0; i--) {
			class_3262 pack = packs.get(i);
			class_7367<InputStream> supplier = pack.method_14405(type, id);

			if (supplier != null) {
				class_7367<class_7368> metadataSupplier = () -> {
					class_7367<InputStream> rawMetadataSupplier = pack.method_14405(this.type, metadataId);
					return rawMetadataSupplier != null ? class_3294.method_45297(rawMetadataSupplier) : class_7368.field_38688;
				};

				resources.add(new class_3298(pack, supplier, metadataSupplier));
			}
		}
	}

	public String getFullName() {
		return this.method_14409() + " (" + this.packs.stream().map(class_3262::method_14409).collect(Collectors.joining(", ")) + ")";
	}

	@Override
	public void close() {
		this.packs.forEach(class_3262::close);
	}
}
