/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.recipe.ingredient.builtin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;

public class AnyIngredient extends CombinedIngredient {
	public static final CustomIngredientSerializer<AnyIngredient> SERIALIZER =
			new CombinedIngredient.Serializer<>(new class_2960("fabric", "any"), AnyIngredient::new);

	public AnyIngredient(class_1856[] ingredients) {
		super(ingredients);
	}

	@Override
	public boolean test(class_1799 stack) {
		for (class_1856 ingredient : ingredients) {
			if (ingredient.method_8093(stack)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public List<class_1799> getMatchingStacks() {
		List<class_1799> previewStacks = new ArrayList<>();

		for (class_1856 ingredient : ingredients) {
			previewStacks.addAll(Arrays.asList(ingredient.method_8105()));
		}

		return previewStacks;
	}

	@Override
	public CustomIngredientSerializer<?> getSerializer() {
		return SERIALIZER;
	}
}
