/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.object.builder;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1299;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7699;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4970.class_2251.class)
public interface AbstractBlockSettingsAccessor {
	/* GETTERS */
	@Accessor
	float getHardness();

	@Accessor
	float getResistance();

	@Accessor
	boolean getCollidable();

	@Accessor
	boolean getRandomTicks();

	@Accessor("luminance")
	ToIntFunction<class_2680> getLuminance();

	@Accessor
	Function<class_2680, class_3620> getMapColorProvider();

	@Accessor
	class_2498 getSoundGroup();

	@Accessor
	float getSlipperiness();

	@Accessor
	float getVelocityMultiplier();

	@Accessor
	float getJumpVelocityMultiplier();

	@Accessor
	boolean getDynamicBounds();

	@Accessor
	boolean getOpaque();

	@Accessor
	boolean getIsAir();

	@Accessor
	boolean isToolRequired();

	@Accessor
	class_4970.class_4972<class_1299<?>> getAllowsSpawningPredicate();

	@Accessor
	class_4970.class_4973 getSolidBlockPredicate();

	@Accessor
	class_4970.class_4973 getSuffocationPredicate();

	@Accessor
	class_4970.class_4973 getBlockVisionPredicate();

	@Accessor
	class_4970.class_4973 getPostProcessPredicate();

	@Accessor
	class_4970.class_4973 getEmissiveLightingPredicate();

	@Accessor
	Optional<class_4970.class_8176> getOffsetter();

	@Accessor
	class_2960 getLootTableId();

	@Accessor
	boolean getBlockBreakParticles();

	@Accessor
	class_7699 getRequiredFeatures();

	@Accessor
	boolean getBurnable();

	@Accessor
	boolean getLiquid();

	@Accessor
	boolean getForceNotSolid();

	@Accessor
	boolean getForceSolid();

	@Accessor
	class_3619 getPistonBehavior();

	@Accessor
	class_2766 getInstrument();

	@Accessor
	boolean getReplaceable();

	/* SETTERS */
	@Accessor
	void setCollidable(boolean collidable);

	@Accessor
	void setRandomTicks(boolean ticksRandomly);

	@Accessor
	void setMapColorProvider(Function<class_2680, class_3620> mapColorProvider);

	@Accessor
	void setDynamicBounds(boolean dynamicBounds);

	@Accessor
	void setOpaque(boolean opaque);

	@Accessor
	void setIsAir(boolean isAir);

	@Accessor
	void setLootTableId(class_2960 lootTableId);

	@Accessor
	void setToolRequired(boolean toolRequired);

	@Accessor
	void setBlockBreakParticles(boolean blockBreakParticles);

	@Accessor
	void setRequiredFeatures(class_7699 requiredFeatures);

	@Accessor
	void setOffsetter(Optional<class_4970.class_8176> offsetter);

	@Accessor
	void setBurnable(boolean burnable);

	@Accessor
	void setLiquid(boolean liquid);

	@Accessor
	void setForceNotSolid(boolean forceNotSolid);

	@Accessor
	void setForceSolid(boolean forceSolid);

	@Accessor
	void setReplaceable(boolean replaceable);
}
