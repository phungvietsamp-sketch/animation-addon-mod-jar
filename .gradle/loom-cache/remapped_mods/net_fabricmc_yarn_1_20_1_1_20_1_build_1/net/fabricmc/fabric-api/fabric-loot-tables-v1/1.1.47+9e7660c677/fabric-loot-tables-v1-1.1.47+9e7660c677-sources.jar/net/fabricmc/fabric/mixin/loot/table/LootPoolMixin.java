/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.loot.table;

import java.util.List;

import com.google.common.collect.ImmutableList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import net.fabricmc.fabric.api.loot.v1.FabricLootPool;
import net.minecraft.class_117;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5658;
import net.minecraft.class_79;

@Mixin(class_55.class)
public abstract class LootPoolMixin implements FabricLootPool {
	@Shadow
	@Final
	class_79[] entries;

	@Shadow
	@Final
	class_5341[] conditions;

	@Shadow
	@Final
	class_117[] functions;

	@Shadow
	@Final
	class_5658 rolls;

	@Override
	public List<class_79> getEntries() {
		return ImmutableList.copyOf(entries);
	}

	@Override
	public List<class_5341> getConditions() {
		return ImmutableList.copyOf(conditions);
	}

	@Override
	public List<class_117> getFunctions() {
		return ImmutableList.copyOf(functions);
	}

	@Override
	public class_5658 getRolls() {
		return rolls;
	}
}
