/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.loot.v1;

import java.util.List;
import net.minecraft.class_117;
import net.minecraft.class_176;
import net.minecraft.class_52;
import net.minecraft.class_55;

/**
 * An interface implemented by all {@link class_52} instances when
 * Fabric API is present. Contains accessors for various fields.
 *
 * @deprecated Replaced with transitive access wideners in Fabric Transitive Access Wideners (v1).
 */
@Deprecated
public interface FabricLootSupplier {
	default class_52 asVanilla() {
		return (class_52) this;
	}

	List<class_55> getPools();
	List<class_117> getFunctions();
	default class_176 getType() {
		return asVanilla().method_322(); // Vanilla has this now
	}
}
