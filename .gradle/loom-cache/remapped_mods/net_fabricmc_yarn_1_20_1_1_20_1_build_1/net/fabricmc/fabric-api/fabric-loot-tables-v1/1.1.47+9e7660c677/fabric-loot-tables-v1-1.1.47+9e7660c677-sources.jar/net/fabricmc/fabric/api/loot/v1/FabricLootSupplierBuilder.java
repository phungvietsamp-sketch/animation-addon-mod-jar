/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.loot.v1;

import java.util.Collection;
import net.fabricmc.fabric.api.loot.v2.FabricLootTableBuilder;
import net.minecraft.class_117;
import net.minecraft.class_176;
import net.minecraft.class_52;
import net.minecraft.class_55;

/**
 * @deprecated Replaced with {@link FabricLootTableBuilder}.
 */
@Deprecated
public class FabricLootSupplierBuilder extends class_52.class_53 {
	protected FabricLootSupplierBuilder() { }

	private FabricLootSupplierBuilder(class_52 supplier) {
		copyFrom(supplier, true);
	}

	private FabricLootTableBuilder asV2() {
		return (FabricLootTableBuilder) this;
	}

	@Override
	public FabricLootSupplierBuilder method_336(class_55.class_56 pool) {
		super.method_336(pool);
		return this;
	}

	@Override
	public FabricLootSupplierBuilder method_334(class_176 type) {
		super.method_334(type);
		return this;
	}

	@Override
	public FabricLootSupplierBuilder method_511(class_117.class_118 function) {
		super.method_335(function);
		return this;
	}

	public FabricLootSupplierBuilder withPool(class_55 pool) {
		asV2().pool(pool);
		return this;
	}

	public FabricLootSupplierBuilder withFunction(class_117 function) {
		asV2().apply(function);
		return this;
	}

	public FabricLootSupplierBuilder withPools(Collection<class_55> pools) {
		asV2().pools(pools);
		return this;
	}

	public FabricLootSupplierBuilder withFunctions(Collection<class_117> functions) {
		asV2().apply(functions);
		return this;
	}

	/**
	 * Copies the pools and functions of the {@code supplier} to this builder.
	 * This is equal to {@code copyFrom(supplier, false)}.
	 */
	public FabricLootSupplierBuilder copyFrom(class_52 supplier) {
		return copyFrom(supplier, false);
	}

	/**
	 * Copies the pools and functions of the {@code supplier} to this builder.
	 * If {@code copyType} is true, the {@link FabricLootSupplier#getType type} of the supplier is also copied.
	 */
	public FabricLootSupplierBuilder copyFrom(class_52 supplier, boolean copyType) {
		FabricLootSupplier extendedSupplier = (FabricLootSupplier) supplier;
		asV2().pools(extendedSupplier.getPools());
		asV2().apply(extendedSupplier.getFunctions());

		if (copyType) {
			method_334(extendedSupplier.getType());
		}

		return this;
	}

	public static FabricLootSupplierBuilder builder() {
		return new FabricLootSupplierBuilder();
	}

	public static FabricLootSupplierBuilder of(class_52 supplier) {
		return new FabricLootSupplierBuilder(supplier);
	}
}
