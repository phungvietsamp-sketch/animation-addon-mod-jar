/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.registry.sync;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.registry.sync.DynamicRegistriesImpl;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3505;
import net.minecraft.class_5321;

// Adds namespaces to tag directories for registries added by mods.
@Mixin(class_3505.class)
abstract class TagManagerLoaderMixin {
	@Inject(method = "getPath", at = @At("HEAD"), cancellable = true)
	private static void onGetPath(class_5321<? extends class_2378<?>> registry, CallbackInfoReturnable<String> info) {
		// TODO: Expand this change to static registries in the future.
		if (!DynamicRegistriesImpl.DYNAMIC_REGISTRY_KEYS.contains(registry)) {
			return;
		}

		class_2960 id = registry.method_29177();

		// Vanilla doesn't mark namespaces in the directories of tags at all,
		// so we prepend the directories with the namespace if it's a modded registry id.
		if (!id.method_12836().equals(class_2960.field_33381)) {
			info.setReturnValue("tags/" + id.method_12836() + "/" + id.method_12832());
		}
	}
}
