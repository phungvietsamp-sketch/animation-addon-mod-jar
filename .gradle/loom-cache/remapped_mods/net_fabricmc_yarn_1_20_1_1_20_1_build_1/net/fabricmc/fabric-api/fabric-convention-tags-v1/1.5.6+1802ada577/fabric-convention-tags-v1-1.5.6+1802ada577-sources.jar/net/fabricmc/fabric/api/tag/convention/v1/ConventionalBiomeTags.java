/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag.convention.v1;

import net.fabricmc.fabric.impl.tag.convention.TagRegistration;
import net.minecraft.class_1959;
import net.minecraft.class_6862;

/**
 * See {@link net.minecraft.class_6908} for vanilla tags.
 * Note that addition to some vanilla tags implies having certain functionality,
 * and as such certain biome tags exist to mirror vanilla tags, and should be preferred
 * over vanilla unless its behavior is desired.
 */
public final class ConventionalBiomeTags {
	private ConventionalBiomeTags() {
	}

	/**
	 * Biomes that spawn in the Overworld.
	 */
	public static final class_6862<class_1959> IN_OVERWORLD = register("in_overworld");
	// The following are based on Biome categories, see Biome$Category for details
	/**
	 * Biomes that spawn in the End.
	 */
	public static final class_6862<class_1959> IN_THE_END = register("in_the_end");
	/**
	 * Biomes that spawn in the Nether.
	 */
	public static final class_6862<class_1959> IN_NETHER = register("in_nether");
	public static final class_6862<class_1959> TAIGA = register("taiga");
	public static final class_6862<class_1959> EXTREME_HILLS = register("extreme_hills");
	public static final class_6862<class_1959> WINDSWEPT = register("windswept");
	public static final class_6862<class_1959> JUNGLE = register("jungle");
	public static final class_6862<class_1959> MESA = register("mesa");
	/**
	 * For temperate or warmer plains-like biomes.
	 * For snowy plains-like biomes, see {@link ConventionalBiomeTags#SNOWY_PLAINS}.
	 */
	public static final class_6862<class_1959> PLAINS = register("plains");
	public static final class_6862<class_1959> SAVANNA = register("savanna");
	/**
	 * For land biomes where ice naturally spawns.
	 * For biomes where snow alone spawns, see {@link ConventionalBiomeTags#SNOWY}.
	 */
	public static final class_6862<class_1959> ICY = register("icy");
	/**
	 * For water biomes where ice naturally spawns.
	 * For biomes where snow alone spawns, see {@link ConventionalBiomeTags#SNOWY}.
	 */
	public static final class_6862<class_1959> AQUATIC_ICY = register("aquatic_icy");
	/**
	 * Biomes that exist on the shoreline of a body of water.
	 */
	public static final class_6862<class_1959> BEACH = register("beach");
	/**
	 * Biomes densely populated with deciduous trees.
	 */
	public static final class_6862<class_1959> FOREST = register("forest");
	public static final class_6862<class_1959> BIRCH_FOREST = register("birch_forest");
	public static final class_6862<class_1959> OCEAN = register("ocean");
	public static final class_6862<class_1959> DESERT = register("desert");
	public static final class_6862<class_1959> RIVER = register("river");
	public static final class_6862<class_1959> SWAMP = register("swamp");
	public static final class_6862<class_1959> MUSHROOM = register("mushroom");
	public static final class_6862<class_1959> UNDERGROUND = register("underground");
	public static final class_6862<class_1959> MOUNTAIN = register("mountain");

	public static final class_6862<class_1959> CLIMATE_HOT = register("climate_hot");
	public static final class_6862<class_1959> CLIMATE_TEMPERATE = register("climate_temperate");
	public static final class_6862<class_1959> CLIMATE_COLD = register("climate_cold");
	public static final class_6862<class_1959> CLIMATE_WET = register("climate_wet");
	public static final class_6862<class_1959> CLIMATE_DRY = register("climate_dry");
	public static final class_6862<class_1959> VEGETATION_SPARSE = register("vegetation_sparse");
	public static final class_6862<class_1959> VEGETATION_DENSE = register("vegetation_dense");
	public static final class_6862<class_1959> TREE_CONIFEROUS = register("tree_coniferous");
	public static final class_6862<class_1959> TREE_SAVANNA = register("tree_savanna");
	public static final class_6862<class_1959> TREE_JUNGLE = register("tree_jungle");
	public static final class_6862<class_1959> TREE_DECIDUOUS = register("tree_deciduous");
	public static final class_6862<class_1959> VOID = register("void");
	public static final class_6862<class_1959> MOUNTAIN_PEAK = register("mountain_peak");
	public static final class_6862<class_1959> MOUNTAIN_SLOPE = register("mountain_slope");
	/**
	 * Biomes consisting primarily of water.
	 */
	public static final class_6862<class_1959> AQUATIC = register("aquatic");
	/**
	 * Barren biomes that lack vegetation.
	 */
	public static final class_6862<class_1959> WASTELAND = register("wasteland");
	/**
	 * Biomes whose flora primarily consists of dead or decaying vegetation.
	 */
	public static final class_6862<class_1959> DEAD = register("dead");
	/**
	 * Biomes with a large amount of flowers.
	 */
	public static final class_6862<class_1959> FLORAL = register("floral");
	/**
	 * For biomes where snow, and not ice, naturally spawns as a predominant feature.
	 * For biomes where ice is a predominant feature, see {@link ConventionalBiomeTags#ICY}.
	 */
	public static final class_6862<class_1959> SNOWY = register("snowy");

	public static final class_6862<class_1959> BADLANDS = register("badlands");
	public static final class_6862<class_1959> CAVES = register("caves");
	/**
	 * Biomes that spawn as or on islands in the End.
	 */
	public static final class_6862<class_1959> END_ISLANDS = register("end_islands");
	public static final class_6862<class_1959> NETHER_FORESTS = register("nether_forests");
	/**
	 * For snowy plains-like biomes.
	 * For warmer plains-like biomes, see {@link ConventionalBiomeTags#PLAINS}.
	 */
	public static final class_6862<class_1959> SNOWY_PLAINS = register("snowy_plains");
	public static final class_6862<class_1959> STONY_SHORES = register("stony_shores");
	public static final class_6862<class_1959> FLOWER_FORESTS = register("flower_forests");
	public static final class_6862<class_1959> DEEP_OCEAN = register("deep_ocean");
	public static final class_6862<class_1959> SHALLOW_OCEAN = register("shallow_ocean");

	private static class_6862<class_1959> register(String tagID) {
		return TagRegistration.BIOME_TAG_REGISTRATION.registerCommon(tagID);
	}
}
